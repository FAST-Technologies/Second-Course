      program main
         INTEGER n, m, ReadFile
         CHARACTER in*60, out*60
         common /files/ in,out
         common /var/ xmin,xmax,dx,ymin,ymax,dy
         common /tables/ n, m
         common /eps/ eps_min, eps_max
         eps_min = 1.175494351E-38     ! Ieieiaeuii aicii?iia cia?aiea
         eps_max = 3.402823466E+38     ! Ieieiaeuii aicii?iia cia?aiea
         in  = 'input.txt'             ! Oaee aey ?oaiey
         out = 'output.txt'            ! Oaee aey caiene
         open(2, FILE=out)
         if (ReadFile().NE.0) then
            print *,'Change file!'
            write (2, *)'Change file!'
         else
            call printTable
         endif
         close(2)
      end !main
   
      INTEGER function Xcheck()
         CHARACTER in*60, out*60
         common /files/ in,out
         common /var/ xmin,xmax,dx,ymin,ymax,dy
         common /eps/ eps_min,eps_max
         common /tables/ n, m
         
         open(2, FILE=out)
         
         if (.not.((eps_min.lt.dx).and.(dx.lt.eps_max))) then ! eps_min < dx < eps_max
            print *, 'dx: step is wrong'
            write (2, *)'dx: step is wrong'
            Xcheck = 1
            RETURN
         endif
    
         if((xmin.lt.xmax).and.(abs(xmax).le.eps_max)
     *   .and.(abs(xmin).ge.0.0)) then
            n = nint((xmax-xmin)/dx) + 1
            Xcheck = 0
            RETURN
         else
            if (dx.lt.0) THEN 
                print *,'Negative x step'
                write (2, *)'Negative x step'
                Xcheck = 1
                RETURN
            else
                print*,'x: The minimum is greater than the maximum'
                write (2, *) 'minimum is greater'
                Xcheck = 1
                RETURN
             end if
         end if
         close(2)
      end !Xcheck
   
      INTEGER function Ycheck()
         CHARACTER in*60, out*60
         common /files/ in,out
         common /var/ xmin,xmax,dx,ymin,ymax,dy
         common /tables/ n,m
         common /eps/ eps_min,eps_max
         
         open(2, FILE=out)

         if (.not.((eps_min.lt.dy).and.(dy.lt.eps_max))) then ! eps_min < dy < eps_max
            print *, 'dy: step is wrong'
            write (2, *)'dy: step is wrong'
            Ycheck = 1
            RETURN
         endif
    
         if((ymin.lt.ymax).and.(abs(ymax).le.eps_max)
     *   .and.(abs(ymin).ge.0.0)) then
            m = nint((ymax-ymin)/dy) + 1
            Ycheck = 0
            RETURN
         else
            if (dy.lt.0) THEN 
                print *,'Negative y step'
                write (2, *)'Negative y step'
                Xcheck = 1
                RETURN
            else
                print*, 'y: The minimum is greater than the maximum'
                write (2, *) 'minimum is greater than the maximum'
                Ycheck = 1
                RETURN
            end if
         end if
         close(2)
      end !Ycheck
      
      INTEGER function ReadFile()
         INTEGER Xcheck, Ycheck
         CHARACTER in*60, out*60
         common /files/ in,out
         common /var/ xmin,xmax,dx,ymin,ymax,dy
         open(1,FILE=in,err=0301)
         read (1,*,err=0302) xmin,xmax,dx,ymin,ymax,dy
         close(1)
         ReadFile = Xcheck() + Ycheck()
         return
         open(2, FILE=out)
0301     print *, 'Error! Can not open file!'
         write (2, *)'Error! Can not open file!'
         ReadFile = 1
         close(2)
         goto 0300
0302     print *, 'Error! Can not read file!'
         write (2, *)'Error! Can not read file! Change file!'
         ReadFile = 1
         close(2)
0300     close(1)
         
      end !readfile
      
      subroutine printTable
         CHARACTER in*60, out*60
         common /files/ in,out
         common /var/ xmin,xmax,dx,ymin,ymax,dy
         common/tables/ n,m         
         logical IsEq
         INTEGER xi, yi, xibeg, xiend
         REAL t

         open(2, FILE=out, err=0401)

         k = 1 + int(n / 500)    ! Ia neo?ae, anee n > 500

         do ki = 1,k
            xibeg = 1 + 500*(ki-1) !
            xiend = min(n, ki*500) !

            prev_y = 0        ! Caanu aoaai o?aieou i?aaoauuee o io oaeouaai. 
            y = ymin          ! caanu aoaai o?aieou oaeouee o
            do yi = 0, m      ! oeee yi = [0;m] (0 aey auaiaa oaiee oaaeeou)
               print *, 'yi: ', yi
               if (yi.gt.1.and.IsEq(prev_y, y)) then  ! anee i?iecio?e iaaeaeiue oaa ii o 
                    print *, 'Invisible step on y: ', y ! (ia o?eouaay eoa?aoee 0 e 1), oi auaiaei yoi a ioeaaeo
                    
                    prev_y = y              ! iaiyai cia?aiey
                    y = ymin + dy*yi        ! y = y + dy
                    CYCLE                ! neeiaai eoa?aoe?
               end if  
   
               if (yi.eq.m) then 
                  y = ymax          ! ia iineaaiae eoa?aoee i?e aicieeiaaiee iaaieuoeo 
                                    ! iia?aoiinoae an? ?aaii aiaiaei y ai ymax
               end if
               
               ! ((y - dy) / (y + dy) + (y + dy) / (y - dy)) / 2 ~ -1.0 a ie?anoiinoe 0
               if (IsEq(-1.0, (y*y + dy*dy) / (y*y - dy*dy))) then
                  y = 0
               end if
               
               if (yi.eq.0) then       ! ia 0 oaaa ia?aoaai ia o, a caaieiaie oaaeeou
                  write (2, '(A, A \)') '    y/x    ',' || '
               else
                  
                    write (2, '(e11.4, '' || '' \)') y
                  
               end if
               
               prev_x = xmin + dx*(xibeg-2)     ! caanu aoaai o?aieou i?aaoauuee o io oaeouaai.
               x = xmin + dx*(xibeg-1)          ! caanu aoaai o?aieou oaeouee o
               !do xi = 1, n   ! oeee xi = [1;n]
               do xi = xibeg, xiend
                 
                  if (xi.gt.1.and.IsEq(prev_x, x)) then  ! anee i?iecio?e iaaeaeiue oaa ii o
                     print *, 'Invisible step on x: ', x ! (ia o?eouaay eoa?aoee 1), oi auaiaei yoi a ioeaaeo
                     
                     prev_x = x              ! iaiyai cia?aiey
                     x = xmin + dx*xi        ! x = x + dx
                     CYCLE                   ! neeiaai eoa?aoe?
                  end if
   
                  if (xi.eq.n) then 
                     x = xmax          ! ia iineaaiae eoa?aoee i?e aicieeiaaiee iaaieuoeo
                                       ! iia?aoiinoae an? ?aaii aiaiaei x ai xmax
                  end if
                  
                  if (IsEq(-1.0, (x*x + dx*dx) / (x*x - dx*dx))) then
                     x = 0
                  end if 
                  if (yi.eq.0) then
                     write (2, '(e11.4, '' | '' \)') x   ! Auaiaei cia?aiey o oieuei a oaiea oaaeeou
                  else
                     t=anint((x+y)*10000)/10000
                     if (IsEq(0.0, abs(mod(t, 180.0000000)))) then     ! Anee x+o = 180*n, oi              
                        write (2, '(A, A \)')'    inf    ', ' | '
                     else
                        val = f(Round(x), Round(y))
                        write (2, '(e11.4, '' | '' \)') val       ! A ooieoe? ia?aaa?i oa cia?aiey, ?oi
                                                                  ! aeaeo iieuciaaoaeu (oi aeou, ie?oae?iiua)
                        
                     end if
                     
                  end if
                  prev_x = x
                  x = xmin + dx*xi     ! x = x + dx
               end do
               write (2, *) ' '
   
               if (yi.ne.0) then 
                  prev_y = y
                  y = ymin + dy*yi     ! y = y + dy
               end if
            end do
            write(2, *) ' '
         end do
         
         close (2)
         RETURN

0401     write(*,*) 'Error open output file (maybe not such directory)'
         write (2, *)'Error open output file (maybe not such directory)'
         close(2)            
      end !printTable
   
      real function f(x,y)
         pi = 3.14159265358979323846
         const = pi/180.0
         f =cotan(x*const+y*const)
      end !f(x,y)
   
      logical function IsEq(val1, val2)
         CHARACTER strVal1*11, strVal2*11
         WRITE(strVal1, '(E11.4)') val1
         WRITE(strVal2, '(E11.4)') val2
         IsEq = strVal1.eq.strVal2
      end !ToStr(val)

      real function Round(val)
         CHARACTER tmpStr*11
         write (tmpStr, '(E11.4)') val
         read (tmpStr, *) Round
      end !Round(val)
