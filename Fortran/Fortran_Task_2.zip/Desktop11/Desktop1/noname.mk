project : C:\Users\ysm47\Desktop\Desktop11\Desktop1\noname.exe .SYMBOLIC

!include C:\Users\ysm47\Desktop\Desktop11\Desktop1\noname.mk1
