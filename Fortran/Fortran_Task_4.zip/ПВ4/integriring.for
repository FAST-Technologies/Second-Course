                  program main
         ! implicit none
         ! integer ngetGrid,nmax,n,moutput, i,k
         ! real step, ansTrap,ansSimps, from,to
         moutput = 200

         print *, 'Input range FROM: '
         read *, from
         print *, 'Input range TO: '
         read *, to
         print *, 'Input number k (where maxsteps = 2^k): '
         read *, k

         print *, 'Choose form of output:'
         print *, '1: linear'
         print *, '2: with steps'
         read *, iform

         print *, 'Choose methods of output (sum it if u need several):'
         print *, '3: gauss-three'
         print *, '4: gauss-five'
         print *, '5: prymaougolniki'
         read *, imethod

         print *, 'Choose precision of methods (or sum it):'
         print *, '1: Real'
         print *, '4: Double (real*8)'
         read *, iprec

         open (moutput, file='output.txt',action='WRITE')
         
            if(from.ge.to) then
                write (moutput, *) 'ERROR RANGE!'
                RETURN
            end if
            
            write (moutput,*) 'Range of integral: [',from,', ',to,']'
            
            if(k.le.0.0) then
                write (moutput, *) 'ERROR k!'
                RETURN
            end if

            if (iprec.eq.1) then
               write(moutput,*)'***************************************'
               write (moutput, *) 'REAL METHODS:'
               call real_menu(moutput, from, to, k, imethod, iform)
            
            else if (iprec.eq.4) then
               write(moutput,*)'***************************************'
               write (moutput, *) 'DOUBLE METHODS:'
               call double_menu(moutput, from, to, k, imethod, iform)
               
            else
               write(moutput,*)'***************************************'
               write (moutput, *) 'FATAL ERROR:'
               RETURN
            end if
            
         close (moutput)
      end !program main

      subroutine real_menu(moutput, from, to, k, imethod, iform)
         real grid(10000000)
         nmax = 10000000

         
         if (iform.eq.1) then
           
           if (imethod.eq.3) then               
               write(moutput, *) 'Gauss-31 method:'
               do i=0,k
                  step = (to - from)/(2**i)
                  n = ngetGrid(grid,nmax,from,to,step)
                  if (n .eq. -1) EXIT
                  rez = gauss3SumReal(n,grid)
                  write(moutput, '(E20.8))') rez
               end do
                        
           
            else if (imethod.eq.4) then               
               write(moutput, *) 'Gauss-51 method:'
               do i=0,k
                  step = (to - from)/(2**i)
                  n = ngetGrid(grid,nmax,from,to,step)
                  if (n .eq. -1) EXIT
                  rez = gauss5SumReal(n,grid)
                  write(moutput, '(E20.14))') rez
               end do
                  
            
           
            else if (imethod.eq.5) then
               write(moutput, *) 'Pryamoigolniki1 method:'
               do i=0,k
                  step = (to - from)/(2**i)
                  n = ngetGrid(grid,nmax,from,to,step)
                  if (n .eq. -1) EXIT
                  rez = pryamSumReal(n,grid)
                  write(moutput, '(E20.8))') rez
               end do
            else
               write(moutput,*)'***************************************'
               write (moutput, *) 'FATAL ERROR: NO METHOD CHOSEN'
               RETURN
            end if 
            

                 
            

         
         else if (iform.eq.2) then
            do i=0,k
               step = (to - from)/(2**i)
               n = ngetGrid(grid,nmax,from,to,step)
               if (n .eq. -1) EXIT

               write(moutput,*) 'Steps: ', 2**i, ', step size: ', step

               
               if (imethod.eq.3) then
                  rez = gauss3SumReal(n,grid)
                  write(moutput, '(A10,E20.8))') 'Gauss-3:', rez
                  
                else if (imethod.eq.4) then
                  rez = gauss5SumReal(n,grid)
                  write(moutput, '(A10,E20.14))') 'Gauss-5: ', rez
               
               else if (imethod.eq.5) then
                  rez = pryamSumReal(n,grid)
                  write(moutput, '(A10,E20.8))') 'Pryamougolniki:', rez
               else
                  write (moutput, *) 'FATAL ERROR: NO METHOD CHOSEN'
                  RETURN
               end if
               !write(moutput,*)
            end do
         else
            write (moutput, *) 'FATAL ERROR: NO SOLUTION'
            RETURN
         end if
      end !subroutine real_menu()

     
      subroutine double_menu(moutput, from, to, k, imethod, iform)
         real*8 gauss5SumDouble
         real*8 gauss3SumDouble, pryamSumDouble, rez
         real*8 grid(10000000)
         nmax = 10000000

         
         if (iform.eq.1) then
            
            
            
            if (imethod.eq.3) then               
               write(moutput, *) 'Gauss-33 method:'
               do i=0,k
                  step = (to - from)/(2**i)
                  n = ngetGridd(grid,nmax,from,to,step)
                  if (n .eq. -1) EXIT
                  rez = gauss3SumDouble(n,grid)
                  write(moutput, '(E25.15)') rez
               end do
                       
            
            else if (imethod.eq.4) then               
               write(moutput, *) 'Gauss-53 method:'
               do i=0,k
                  step = (to - from)/(2**i)
                  n = ngetGridd(grid,nmax,from,to,step)
                  if (n .eq. -1) EXIT
                  rez = gauss5SumDouble(n,grid)
                  write(moutput, '(E25.15)') rez
               end do
              
                      
            
            else if (imethod.eq.5) then               
               write(moutput, *) 'Pryamougolniki3 method:'
               do i=0,k
                  step = (to - from)/(2**i)
                  n = ngetGridd(grid,nmax,from,to,step)
                  if (n .eq. -1) EXIT
                  rez = pryamSumDouble(n,grid)
                  write(moutput, '(E25.15)') rez
               end do
            else
               write(moutput,*)'***************************************'
               write (moutput, *) 'FATAL ERROR: NO METHOD CHOSEN'
               RETURN
            end if
                        

         else if (iform.eq.2) then
            do i=0,k
               step = (to - from)/(2**i)
               n = ngetGridd(grid,nmax,from,to,step)
               if (n .eq. -1) EXIT

               write(moutput,*) 'Steps: ', 2**i, ', step size: ', step

               
               if (imethod.eq.3) then
                  rez = gauss3SumDouble(n,grid)
                  write(moutput, '(A10,E25.15)') 'Gauss-3:', rez
                  
               else if (imethod.eq.4) then
                  rez = gauss5SumDouble(n,grid)
                  write(moutput, '(A10,E25.15)') 'Gauss-5:', rez
               
               else if (imethod.eq.5) then
                  rez = pryamSumDouble(n,grid)
                  write(moutput, '(A10,E25.15)') 'Pryamougolniki:', rez
               
               else
                  write (moutput, *) 'FATAL ERROR: NO METHOD CHOSEN'
                  RETURN
               end if
               !write(moutput,*)
            end do
         else
            write (moutput, *) 'FATAL ERROR: NO SOLUTION'
            RETURN
         end if
      end !subroutine semiDouble_menu()
   ! eiiao iaeanoe iai?oae

      INTEGER function ngetGrid(grid,nmax,xbeg,xend,xstep)
         ! implicit none
         ! integer n,nmax,i,nint
         ! real xbeg,xend,xstep
         real grid(*)

         n = nint((xend - xbeg) / xstep) + 1

         if (n .gt. nmax) then 
            print *, 'Error: size of grid too large to fit in array'
            ngetGrid = -1
            RETURN
         end if

         do i = 1,n-1
            grid(i) = xbeg + xstep*(i-1)
         end do

         grid(n) = xend

         ngetGrid = n
         RETURN
      end !subroutine ngetGrid
      
       INTEGER function ngetGridd(grid,nmax,xbeg,xend,xstep)
         ! implicit none
         ! integer n,nmax,i,nint
         ! real xbeg,xend,xstep
         real*8 grid(*)

         n = nint((xend - xbeg) / xstep) + 1

         if (n .gt. nmax) then 
            print *, 'Error: size of grid too large to fit in array'
            ngetGrid = -1
            RETURN
         end if

         do i = 1,n-1
            grid(i) = xbeg + xstep*(i-1)
         end do

         grid(n) = xend

         ngetGridd = n
         RETURN
      end !subroutine ngetGrid

  
      
      
      real function pryamSumReal(n,grid)
         implicit none
         integer n, i
         real step, deltasum, fun
         real grid(*)

         if (n .lt. 2) then
            print *, 'Error: grid in pryamSumReal too short.'
            pryamSumReal = 0.0
            RETURN
         end if
         
         
         deltasum = 0.0
         do i=1,n-1
            step = grid(i+1)-grid(i)
            deltasum = deltasum + step*fun((grid(i)+grid(i+1))/2.0)
         end do
         
         
         pryamSumReal = deltasum
      
      end !real function pryamSumReal(n,grid)

      
      real function gauss3SumReal(n, grid)
         implicit none
         integer j,k,n
         real roots(3), weights(3), grid(*), step, sum, tsum, x_kj, fun
         roots(1) = (sqrt(3.0 / 5.0))
         roots(2) = -(sqrt(3.0 / 5.0))
         roots(3) =  0.0
        
         weights(1) = 5.0/9.0
         weights(2) = 5.0/9.0
         weights(3) =  8.0/9.0
 
         sum = 0.0
         do j=1,3
            tsum = 0.0
            do k=2,n
               step = grid(k) - grid(k-1)
               x_kj = ((grid(k-1)+grid(k)) + roots(j)*step)/2.0
               tsum = tsum + step*fun(x_kj)
            end do
            sum = sum + weights(j)*tsum
         end do

         gauss3SumReal = sum / 2.0
      end !real function gauss3SumReal(n, grid)

      real function gauss5SumReal(n, grid)
         implicit none
         integer j,k,n
         real roots(5), weights(5), grid(*), step, sum, tsum, x_kj, fun
         roots(1) = (sqrt(5.0 - 2.0*sqrt(10.0 / 7.0)) / 3.0)
         roots(2) = -(sqrt(5.0 - 2.0*sqrt(10.0 / 7.0)) / 3.0)
         roots(3) =  (sqrt(5.0 + 2.0*sqrt(10.0 / 7.0)) / 3.0)
         roots(4) =  -(sqrt(5.0 + 2.0*sqrt(10.0 / 7.0)) / 3.0)
         roots(5) = 0.0

         weights(1) = ((322.0 + 13.0*sqrt(70.0)) / 900.0)
         weights(2) = ((322.0 + 13.0*sqrt(70.0)) / 900.0)
         weights(3) = ((322.0 - 13.0*sqrt(70.0)) / 900.0)
         weights(4) = ((322.0 - 13.0*sqrt(70.0)) / 900.0)
         weights(5) = (128.0/225.0)

 
         sum = 0.0
         do j=1,5
            tsum = 0.0
            do k=2,n
               step = grid(k) - grid(k-1)
               x_kj = ((grid(k-1)+grid(k)) + roots(j)*step)/2.0
               tsum = tsum + step*fun(x_kj)
            end do
            sum = sum + weights(j)*tsum
         end do

         gauss5SumReal = sum / 2.0
      end !real function gauss5SumReal(n, grid)
   
      
      
      
      
      
      
      real*8 function pryamSumDouble(n,grid)
         implicit none
         integer n, i
         real*8 grid(*)
         real*8 deltasum, dfun, step

         if (n .lt. 2) then
            print *, 'Error: grid in pryamSumDouble too short.'
            pryamSumDouble = 0.0D0
            RETURN
         end if
      
         deltasum = 0.0D0
         do i=1,n-1
            step = grid(i+1)-grid(i)
            deltasum = deltasum + step*dfun((grid(i)+grid(i+1))/2.0D0)
         end do
         
         
         pryamSumDouble = deltasum
      
      
      
      end !real*8 function pryamSumDouble(n,grid)

      
      real*8 function gauss3SumDouble(n, grid)
         implicit none
         integer j,k,n
         real*8 grid(*)
         real*8 roots(3),weights(3), sum,tsum,step,x_kj, dfun
         roots(1) = (sqrt(3.0D0 / 5.0D0))
         roots(2) = -(sqrt(3.0D0 / 5.0D0))
         roots(3) =  0.0D0
        
         weights(1) = 5.0D0/9.0D0
         weights(2) = 5.0D0/9.0D0
         weights(3) =  8.0D0/9.0D0

         sum = 0.0D0
         do j=1,3
            tsum = 0.0D0
            do k=2,n
               step = grid(k) - grid(k-1)
               x_kj = ((grid(k-1)+grid(k)) + roots(j)*step)/2.0D0
               tsum = tsum + step*dfun(x_kj)
            end do

            sum = sum + weights(j)*tsum
         end do

         gauss3SumDouble = sum / 2.0D0
      end !real*8 function gauss3SumDouble(n, grid)
      
      
      
      real*8 function gauss5SumDouble(n, grid)
         implicit none
         integer j,k,n
         real*8 grid(*)
         real*8 roots(5),weights(5), sum,tsum,step,x_kj, dfun
         roots(1) = sqrt(5.0D0 - 2.0D0*sqrt(10.0D0 / 7.0D0)) / 3.0D0
         roots(2) = -sqrt(5.0D0 - 2.0D0*sqrt(10.0D0 / 7.0D0)) / 3.0D0
         roots(3) =  sqrt(5.0D0 + 2.0D0*sqrt(10.0D0 / 7.0D0)) / 3.0D0
         roots(4) =  -sqrt(5.0D0 + 2.0D0*sqrt(10.0D0 / 7.0D0)) / 3.0D0
         roots(5) = 0.0D0

         weights(1) = (322.0D0 + 13.0D0*sqrt(70.0D0)) / 9.0D2
         weights(2) = (322.0D0 + 13.0D0*sqrt(70.0D0)) / 9.0D2
         weights(3) = (322.0D0 - 13.0D0*sqrt(70.0D0)) / 9.0D2
         weights(4) = (322.0D0 - 13.0D0*sqrt(70.0D0)) / 9.0D2
         weights(5) = 128.0D0/225.0D0
         
         sum = 0.0D0
         do j=1,5
            tsum = 0.0D0
            do k=2,n
               step = grid(k) - grid(k-1)
               x_kj = ((grid(k-1)+grid(k)) + roots(j)*step)/2.0D0
               tsum = tsum + step*dfun(x_kj)
            end do

            sum = sum + weights(j)*tsum
         end do

         gauss5SumDouble = sum / 2.0D0
      end !real*8 function gauss5SumDouble(n, grid)

      real function fun(x)
         implicit none
         real x

         fun = COS(2.0*x-3.0)+2.0*SIN(3.0*x+3.0)
         RETURN
      end !real function fun()

      real*8 function dfun(x)
         implicit none
         real*8 x

         dfun = COS(2D0*x-3D0)+2D0*SIN(3D0*x+3D0)
         RETURN
      end !real*8 function dfun()


