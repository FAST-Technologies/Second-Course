project : "C:\Users\ysm47\Desktop\��4\integriring.exe" .SYMBOLIC

!include "C:\Users\ysm47\Desktop\��4\integriring.mk1"
