project : C:\Users\ysm47\Desktop\FortranProj311\Programms\MainMain\MainMain.&
exe .SYMBOLIC

!include C:\Users\ysm47\Desktop\FortranProj311\Programms\MainMain\MainMain.m&
k1
