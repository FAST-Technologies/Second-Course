! [diag|au|al|ja|ia|vec|ans|free]
! 1...n                         = diag...(diag + n - 1) - diagonal (n)
! (n + 1)...(n + m)             = au...(au + m - 1)     - au (m)
! (n + m + 1)...(n + 2m)        = al...(al + m - 1)     - al (m)
! (n + 2m + 1)...(n + 3m)       = ja...(ja + m - 1)     - ja (m)
! (n + 3m + 1)...(2n + 3m + 1)  = ia...(ia + n)         - ia (n+1)
! (2n + 3m + 2)...(3n + 3m + 1) = vec...(vec + n - 1)   - vec (n)
! (3n + 3m + 2)...(4n + 3m + 1) = ans...(ans + n - 1)   - answer (n)
! (4n + 3m + 2)...maxSize                               - free RAM

      program main
         implicit none
         real arr(268435455) ! 268'435'455 - ������ �� 1 ��
         integer diag,au,al,ja,ia,vec,ans
         integer n,m,maxSize
         common /sizes/ n,m,maxSize

         logical readSizes,readData,outMas ! ��������� �������

         maxSize = 268435455

         ! ������ ������� �������� � �������� �������� ��� �������
         ! ������� � ������
         if (.not.(readSizes())) RETURN
         diag = 1
         au = diag + n     ! n + 1
         al = au + m       ! n + m + 1
         ja = al + m       ! n + 2m + 1
         ia = ja + m       ! n + 3m + 1
         vec = ia + n + 1  ! 2n + 3m + 2
         ans = vec + n     ! 3n + 3m + 2

        

         ! ��������� ������ � ��������������� �������
         if (.not.(readData(arr(diag),arr(au),arr(al),arr(ja),
     *   arr(ia),arr(vec)))) RETURN

         CALL mult(arr(diag),arr(au),arr(al),arr(ja),arr(ia),arr(vec),
     *   arr(ans))

         if (.not.(outMas(n,arr(ans)))) RETURN
      end !main

      logical function readSizes()
         implicit none
         integer n,m,maxSize
         common /sizes/ n,m,maxSize

         open (11,file='files/sizes.txt',action='READ',ERR=311)
         read (11, *, ERR=321) n,m
         close(11)
         maxSize = 268435455
         
         if (n.le.0 .or. m.le.0) then
            print *, 'Size is less then zero!'
            open (88,file='MainOutput.txt',action='WRITE')
            write(88,*) 'Size is less then zero!'
            close(88)
            goto 399
         end if
         ! �������� �� ������������ ������ �������� (����� ������ � ������)
         if ((4*n + 3*m + 1).gt.maxSize) then
            print *, 'Error: too large matrix, program was terminated'
            open (88,file='MainOutput.txt',action='WRITE')
            write(88,*) 'too large matrix'
            close(88)
            goto 399
         end if

         readSizes = .true.
         RETURN

311      print *, 'Error at open file [sizes.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at open file [sizes.txt]'
         close(88)
         goto 399
         
321      print *, 'Error at read file [sizes.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at open file [sizes.txt]'
         close(88)
         goto 399

399      readSizes = .false.
         RETURN
      end !logical function readSizes()

      logical function readData(diag,au,al,ja,ia,vec)
         implicit none
         integer n,m,maxSize
         common /sizes/ n,m,maxSize
         integer ja(*),ia(*)
         real diag(*),au(*),al(*),vec(*)
         integer i

         open (22,file='files/di.txt',action='READ',ERR=112)
         read (22, *, ERR=122) (diag(i), i = 1, n)
         close (22) 

         open (33,file='files/au.txt',action='READ',ERR=113)
         read (33, *, ERR=123) (au(i), i = 1, m)
         close (33) 

         open (44, file = 'files/al.txt', action = 'READ', ERR=114)
         read (44, *, ERR=124) (al(i), i = 1, m)
         close (44) 

         open (55, file = 'files/ja.txt', action = 'READ', ERR=115)
         read (55, *, ERR=125) (ja(i), i = 1, m)
         close (55) 

         open (66, file = 'files/ia.txt', action = 'READ', ERR=116)
         read (66, *, ERR=126) (ia(i), i = 1, n+1)
         close (66) 

         open (77, file = 'files/vector.txt', action = 'READ', ERR=117)
         read (77, *, ERR=127) (vec(i), i = 1, n)
         close (77)
         
         readData = .true.
         RETURN
         ! Errors when open files:
112      print *, 'Error at open file [di.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at open file [di.txt]'
         close(88)
         goto 199
113      print *, 'Error at open file [au.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at open file [au.txt]'
         close(88)
         goto 199
114      print *, 'Error at open file [al.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at open file [al.txt]'
         close(88)
         goto 199
115      print *, 'Error at open file [ja.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at open file [ja.txt]'
         close(88)
         goto 199
116      print *, 'Error at open file [ia.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at open file [ia.txt]'
         close(88)
         goto 199
117      print *, 'Error at open file [vector.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at open file [vector.txt]'
         close(88)
         goto 199

         ! Errors when read from files:
122      print *, 'Error at read file [di.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at read file [di.txt]'
         close(88)
         goto 199
123      print *, 'Error at read file [au.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at read file [au.txt]'
         close(88)
         goto 199
124      print *, 'Error at read file [al.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at read file [al.txt]'
         close(88)
         goto 199
125      print *, 'Error at read file [ja.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at read file [ja.txt]'
         close(88)
         goto 199
126      print *, 'Error at read file [ia.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at read file [ia.txt]'
         close(88)
         goto 199
127      print *, 'Error at read file [vector.txt]'
         open (88,file='MainOutput.txt',action='WRITE')
         write(88,*) 'Error at read file [vector.txt]'
         close(88)
         goto 199

199      readData = .false.
         RETURN
      end !logical function readData(diag,au,al,ja,ia,vec)

      logical function outMas(size, mas)
         real mas(*)
         integer size,k

         open (88,file='MainOutput.txt',action='WRITE',ERR=218)
         do k = 1,size
            write (88, '(F11.3)') mas(k)
         end do
         close(88)
         outMas = .true.
         RETURN

218      print *, 'Error open file [MainOutput.txt]'
         close(88)
         outMas = .false.
         RETURN
      end !logical function outMas(mas)

      subroutine mult(diag,au,al,ja,ia,vec,ans)
         real diag(*),au(*),al(*),vec(*),ans(*)
         integer ja(*),ia(*)
         integer i,j,i_beg,i_end,n,m,maxSize
         common /sizes/ n,m,maxSize

         ! ������� ���������� ������������ ��������
         do i=1,n
            ans(i) = diag(i)*vec(i)
         end do

         ! ����� ���������� ������������ (����� ������� � ������)
         do j=1,n
            if (ia(j) .eq. ia(j+1)) cycle

            i_beg = int(ia(j))
            i_end = int(ia(j+1)) - 1
            do i = i_beg,i_end
               ! ��� �������� ������������
               ans(int(ja(i))) = ans(int(ja(i))) + al(i)*vec(j)
               ! ��� ������� ������������
               ans(j) = ans(j) + au(i)*vec(int(ja(i)))
            end do
         end do

      end !subroutine mult(diag,au,al,ja,ia,vec,ans)

