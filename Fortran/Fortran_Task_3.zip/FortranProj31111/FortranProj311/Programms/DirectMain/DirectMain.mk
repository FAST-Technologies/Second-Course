project : C:\Users\yamshhikov.2022\Downloads\FortranProj31\Programms\DirectM&
ain\DirectMain.exe .SYMBOLIC

!include C:\Users\yamshhikov.2022\Downloads\FortranProj31\Programms\DirectMa&
in\DirectMain.mk1
