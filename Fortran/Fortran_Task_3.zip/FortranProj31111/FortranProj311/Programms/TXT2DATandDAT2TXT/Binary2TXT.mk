project : C:\Users\yamshhikov.2022\Downloads\FortranProj31\Programms\TXT2DAT&
andDAT2TXT\Binary2TXT.exe .SYMBOLIC

!include C:\Users\yamshhikov.2022\Downloads\FortranProj31\Programms\TXT2DATa&
ndDAT2TXT\Binary2TXT.mk1
