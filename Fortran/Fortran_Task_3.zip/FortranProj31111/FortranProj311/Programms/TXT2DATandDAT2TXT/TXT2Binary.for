        program main
        common /size/ N, N_al
        call todirect(ia, di, al, au, ja, V)
        pause
        end
        
        subroutine todirect(ia, di, al, au, ja, V)
        common /size/ N, N_al
        dimension ia(*), di(*), al(*), au(*), ja(*)
        open(1, file = 'sizes.txt', status = 'old', err = 1)
        read(1, *) N
        close(1)
        open(1, file = 'ia.txt', status = 'old', err = 2)
        read(1, *) (values, i = 1, N + 1)
        N_al = INT(values) - 1
        close(1)
        call matrixTodir(ia, di, al, au, ja)
        call vectorTodir(V)
        return
    1 print *, 'sizes.txt file does not exist!'
        pause
        stop
    2 print *, 'ia.txt does not exist!'
        pause
        stop
        end

        subroutine matrixTodir(ia, di, al, au, ja)
        common /size/ N, N_al
        dimension ia(*), di(*), al(*), au(*), ja(*)
        open(1, file = 'ia.txt', status = 'old', err = 1)
        open(2, file = 'ia.dat', access = 'direct', recl = 4)
        read(1, *) (ia(i), i = 1, N + 1)
        do i = 1, N + 1
        write(2, rec = i) ia(i)
        end do
        close(1)
        close(2)
        open(1, file = 'di.txt', status = 'old', err = 2)
        open(2, file = 'di.dat', access = 'direct', recl = 4)
        read(1, *) (di(i), i = 1, N)
        do i = 1, N
        write(2, rec = i) di(i)
        end do
        close(1)
        close(2)
        open(1, file = 'al.txt', status = 'old', err = 3)
        open(2, file = 'al.dat', access = 'direct', recl = 4)
        read(1, *) (al(i), i = 1, N_al)
        do i = 1, N_al
        write(2, rec = i) al(i)
        end do
        close(1)
        close(2)
        open(1, file = 'au.txt', status = 'old', err = 4)
        open(2, file = 'au.dat', access = 'direct', recl = 4)
        read(1, *) (au(i), i = 1, N_al)
        do i = 1, N_al
        write(2, rec = i) au(i)
        end do
        close(1)
        close(2)
        open(1, file = 'ja.txt', status = 'old', err = 5)
        open(2, file = 'ja.dat', access = 'direct', recl = 4)
        read(1, *) (ja(i), i = 1, N_al)
        do i = 1, N_al
        write(2, rec = i) ja(i)
        end do
        close(1)
        close(2)
        print *, 'Sequential to direct matrix convertion completed.'
        return
    1 print *, 'ia.txt does not exist!'
        pause
        stop
    2 print *, 'di.txt does not exist!'
        pause
        stop
    3 print *, 'al.txt does not exist!'
        pause
        stop
    4 print *, 'au.txt does not exist!'
        pause
        stop
    5 print *, 'ja.txt does not exist!'
        pause
        stop
        end
        
        subroutine vectorTodir(V)
        common /size/ N, N_al
        dimension V(*)
        open(1, file = 'vector.txt', status = 'old', err = 1)
        open(2, file = 'vector.dat', access = 'direct', recl = 4)
        read(1, *) (V(i), i = 1, N)
        do i = 1, N
        write(2, rec = i) V(i)
        end do
        close(1)
        close(2)
        print *, 'Sequential to direct vector convertion completed.'
        return
    1 print *, 'vector.txt does not exist!'
        pause
        stop
        end

