project : C:\Users\ysm47\Desktop\projects\Programms\TXT2DATandDAT2TXT\TXTtoB&
inary.exe .SYMBOLIC

!include C:\Users\ysm47\Desktop\projects\Programms\TXT2DATandDAT2TXT\TXTtoBi&
nary.mk1
