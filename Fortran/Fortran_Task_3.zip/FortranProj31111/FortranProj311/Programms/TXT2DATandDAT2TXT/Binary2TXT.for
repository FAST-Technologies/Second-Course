        program main
        common /size/ N, N_al
        call toSequential()
        pause
        end

        subroutine toSequential()
        common /size/ N, N_al
        open(1, file = 'files/sizes.txt', status = 'old', err = 1)
        read(1, *) N
        close(1)
        open(1, file = 'files/ia.dat', access='direct', recl=4, err = 2)
        read(1, rec = N + 1) j
        N_al = j - 1
        close(1)
        call matrixToSeq()
        call vectorToSeq()
        return
    1 print *, 'sizes.txt file does not exist!'
        pause
        stop
    2 print *, 'ia.dat does not exist!'
        pause
        stop
        end
        
        subroutine matrixToSeq()
        common /size/ N, N_al
        open(1, file='files/ia.dat', access='direct', recl=4)
        open(2, file = 'files/ia_1.txt')
        do i = 1, N + 1
        read(1, rec = i) j
        write(2, 200) j
        end do
        close(1)
        close(2)
        open(1, file='files/ja.dat', access='direct', recl=4)
        open(2, file = 'files/ja_1.txt')
        do i = 1, N_al
        read(1, rec = i) j
        write(2, 200) j
        end do
        close(1)
        close(2)
        open(1, file='files/di.dat', access='direct', recl=4)
        open(2, file = 'files/di_1.txt')
        do i = 1, N
        read(1, rec = i) a
        write(2, 100) a
        end do
        close(1)
        close(2)
        open(1, file='files/al.dat', access='direct', recl=4)
        open(2, file='files/au.dat', access='direct', recl=4)
        open(3, file = 'files/al_1.txt')
        open(4, file = 'files/au_1.txt')
        do i = 1, N_al
        read(1, rec = i) a
        read(2, rec = i) b
        write(3, 100) a
        write(4, 100) b
        end do
        close(1)
        close(2)
        close(3)
        close(4)
        print *, 'direct to sequential MATRIX convertion completed.'
        return
 100  format(E11.4, ' ')
 200  format(I4, ' ')
        end
        
        subroutine vectorToSeq()
        common /size/ N, N_al
        open(1, file = 'files/vector.dat', access = 'direct', recl = 4)
        open(2, file = 'files/vector_1.txt')
        do i = 1, N
        read(1, rec = i) a
        write(2, 100) a
        end do
        close(1)
        close(2)
        open(3, file = 'files/tr.dat', access = 'direct', recl = 4)
        open(4, file = 'files/tr_1.txt')
        do i = 1, N
        read(3, rec = i) a
        write(4, 100) a
        end do
        close(3)
        close(4)
        print *, 'direct to sequential VECTOR convertion completed.'
        return
 100  format(E11.4, ' ')
        End

