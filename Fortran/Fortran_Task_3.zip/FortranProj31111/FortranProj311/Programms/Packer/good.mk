project : C:\Users\ysm47\Desktop\FortranProj311\Programms\Packer\good.exe .S&
YMBOLIC

!include C:\Users\ysm47\Desktop\FortranProj311\Programms\Packer\good.mk1
