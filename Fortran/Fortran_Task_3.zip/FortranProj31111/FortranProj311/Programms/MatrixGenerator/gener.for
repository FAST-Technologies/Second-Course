            program main
      implicit none
      integer type, n, m, i, j, counter, counter1, selected
      real matrix(16383,16383), vect(16383), t, result(16383), summ
      common/sizeg/n,m,counter
      counter=0
      counter1=0
      summ=0
      write(*, *) 'print type: '
      read(*, *) type
      write(*, *) 'print n: '
      read(*, *) n
      write(*, *) 'print m'
      read(*, *) m
      if((n.ge.16383).or.(n.lt.1)) then
      open(21,file='input.txt',action='WRITE')
      print *, 'n size is broken'
      write (21,*) 'n size is broken'
      close(21)
      return 
      end if
      if((m.lt.0).or.(m.gt.0.5*(n-1)*n)) then
      open(21,file='input.txt',action='WRITE')
      print *, ' m size is broken'
      write (21,*) 'm size is broken'
      close(21)
      return 
      end if
      do i = 1, n
        do j = 1, n
            matrix(i,j)=0.0
        end do
      end do
      t = real((m + n))/n
      
          do i = 1, n
            matrix(i, i)=t+i+0.1
            end do
        
            do i = 2, n
                do j = 1, i-1
                        
                            if (counter.eq.m) then
                                GO TO 14
                            end if
                            matrix(i,j)=4*t-0.2*i
                            counter=counter+1
                end do
            end do
            
  14    print *, '===='
        
            do j = 2, n
                do i = 1, j-1
                        if (counter1.eq.m) then
                            GO TO 12
                        end if
                        ! if(counter1.eq.m) then
                        !         stop
                        ! end if
                        matrix(i,j)=4*t-0.1*i
                        counter1=counter1+1
                end do
            end do
            
   12    print *, '===='
                
        do i = 1, n
            write(*, *) (matrix(i,j), j=1,n)
        end do
        
        do i = 1, n
            vect(i)=1+t*i*n
        end do
        
        do i = 1, n
            write(*, *) vect(i)
        end do
        
        if(type.eq.1) then
            open(21,file='input.txt',action='WRITE')
            write (21,*) 'b'
            write(21,'(I2)') n, m
            do i = 1, n
                write(21, *) (matrix(i,j), j=1,n)
            end do
            do i = 1, n
                write(21, *) vect(i)
            end do
            close(21)
        else if (type.eq.2) then
            open(21,file='input.txt',action='WRITE')
            write (21,*) 't'
            write(21,'(I2)') n, m
            do i = 1, n
                write(21, *) (matrix(i,j), j=1,n)
            end do
            do i = 1, n
                write(21, *) vect(i)
            end do
            close(21)
        else
            open(21,file='input.txt',action='WRITE')
            print *, 'type is wrong'
            write (21,*) 'type is wrong'
            close(21)
            return
        end if
        open(31, file='input.txt',action='READ',ERR=100)
        read (31, '(A20)', ERR=101) selected
        read (31, *, ERR=202) n
        read (31, *, ERR=202) m
        do i=1,n
            read (31, *, ERR=200) (matrix(i,j), j=1,n)
        end do
        read (31, *, ERR=201) (vect(i), i=1,n)
        do i=1,n
            summ=0
            do j=1,n 
                summ = summ + matrix(i,j)*vect(j)
            end do
            result(i)=summ
            print *, 'resultel', result(i)
            
        end do
        open(32,FILE='result.txt',action='WRITE')
            write(32,'(F11.3)') (result(j), j=1,n)
        close (32)
        goto 102
        
100      print *, 'Error opening file input.txt when reading switcher.'
         goto 102
101      print *, 'Error reading file input.txt when reading switcher.'

102      close (31)
         RETURN
200      print *, 'Error reading matrix on i = ', i   !'Error opening file input.txt when reading arrays.'
         RETURN
201      print *, 'Error reading file input.txt when reading arrays.'
         RETURN
202      print *, 'Error reading file input.txt when reading size.'
      end
