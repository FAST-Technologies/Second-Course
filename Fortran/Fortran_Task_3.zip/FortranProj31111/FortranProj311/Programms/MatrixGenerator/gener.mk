project : C:\Users\ysm47\Desktop\FortranProj311\Programms\MatrixGenerator\ge&
ner.exe .SYMBOLIC

!include C:\Users\ysm47\Desktop\FortranProj311\Programms\MatrixGenerator\gen&
er.mk1
