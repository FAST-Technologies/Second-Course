      program main
         implicit none
         real arr(268435455) ! 268'435'455 - ������ �� 1 ��
         integer diag,au,al,ja,ia
         integer i,j,n,m,maxSize,k
         common /sizes/ n,m,maxSize
         logical readSizes, readData
         real get

         maxSize = 268435455

         if (.not.(readSizes())) RETURN
         diag = 1
         au = diag + n     ! n + 1
         al = au + m       ! n + m + 1
         ja = al + m       ! n + 2m + 1
         ia = ja + m       ! n + 3m + 1

         ! ������ ������� �������� � �������� �������� ��� �������
         ! ������� � ������
         if (.not.(readData(arr(diag),arr(au),arr(al),arr(ja),
     *   arr(ia)))) RETURN

         open(121,file='matrixFromTxt.txt',action='write')
         do i=1,n
            write (121,*) (get(i,j,arr(diag),arr(au),arr(al),
     *      arr(ja),arr(ia)), j=1,n)
         end do
         
         close(121)
      end !program main

      logical function readSizes()
         implicit none
         integer n,m,maxSize
         common /sizes/ n,m,maxSize

         open (11,file='files/sizes.txt',action='READ',ERR=311)
         read (11, *, ERR=321) n,m
         close(11)

         ! �������� �� ������������ ������ �������� (����� ������ � ������)
         if ((4*n + 3*m + 1).gt.maxSize) then
            print *, 'Error: too large matrix, program was terminated'
            goto 399
         end if

         readSizes = .true.
         RETURN

311      print *, 'Error at open file [files/sizes.txt]'
         goto 399
         
321      print *, 'Error at read file [files/sizes.txt]'
         goto 399

399      readSizes = .false.
         RETURN
      end !logical function readSizes()

      logical function readData(diag,au,al,ja,ia)
         implicit none
         integer n,m,maxSize
         common /sizes/ n,m,maxSize
         real diag(*),au(*),al(*),ja(*),ia(*)
         integer i

         open (22,file='files/di.txt',action='READ',ERR=112)
         read (22, *, ERR=122) (diag(i), i = 1, n)
         close (22) 

         open (33,file='files/au.txt',action='READ',ERR=113)
         read (33, *, ERR=123) (au(i), i = 1, m)
         close (33) 

         open (44, file = 'files/al.txt', action = 'READ', ERR=114)
         read (44, *, ERR=124) (al(i), i = 1, m)
         close (44) 

         open (55, file = 'files/ja.txt', action = 'READ', ERR=115)
         read (55, *, ERR=125) (ja(i), i = 1, m)
         close (55) 

         open (66, file = 'files/ia.txt', action = 'READ', ERR=116)
         read (66, *, ERR=126) (ia(i), i = 1, n+1)
         close (66) 
         
         readData = .true.
         RETURN
         ! Errors when open files:
112      print *, 'Error at open file [files/di.txt]'
         goto 199
113      print *, 'Error at open file [files/au.txt]'
         goto 199
114      print *, 'Error at open file [files/al.txt]'
         goto 199
115      print *, 'Error at open file [files/ja.txt]'
         goto 199
116      print *, 'Error at open file [files/ia.txt]'
         goto 199

         ! Errors when read from files:
122      print *, 'Error at read file [files/di.txt]'
         goto 199
123      print *, 'Error at read file [files/au.txt]'
         goto 199
124      print *, 'Error at read file [files/al.txt]'
         goto 199
125      print *, 'Error at read file [files/ja.txt]'
         goto 199
126      print *, 'Error at read file [files/ia.txt]'
         goto 199

199      readData = .false.
         RETURN
      end !logical function readData(diag,au,al,ja,ia)

      
      function get(i,j,diag,au,al,ja,ia)
         implicit none
         ! real arr(268435455) ! 268'435'455 - ������ �� 1 ��
         real diag(*),au(*),al(*),ja(*),ia(*)
         integer n,m,i,j,k,maxSize,j_beg,j_end
         common /sizes/ n,m,maxSize

         
         if ((i.le.0.and.j.le.0).or.(i.gt.n.and.j.gt.n)) then
            get = 0
            RETURN
         end if

         
         if (i.eq.j) then
            get = diag(i)
            RETURN
         end if

        
         if (j.gt.i) then
            j_beg = ia(i)
            j_end = ia(i+1)-1

            
            if (j_beg.eq.(j_end + 1)) then
               get = 0
               RETURN
            end if

            
            do k=j_beg,j_end
               if (ja(k).eq.j) then
                  get = au(k)
                  RETURN
               end if
            end do

            
            get = 0
            RETURN
         end if

         
         if (j.lt.i) then
            j_beg = ia(j)
            j_end = ia(j+1)-1
            
            
            if (j_beg.eq.(j_end + 1)) then
               get = 0
               RETURN
            end if

            
            do k=j_beg,j_end
               if (ja(k).eq.i) then
                  get = al(k)
                  RETURN
               end if
            end do

            
            get = 0
            RETURN
         end if

      end !function get(i,j)
