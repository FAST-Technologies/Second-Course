project : C:\Users\ysm47\Desktop\projects\Programms\Translator-creator\binar&
yTranslator.exe .SYMBOLIC

!include C:\Users\ysm47\Desktop\projects\Programms\Translator-creator\binary&
Translator.mk1
