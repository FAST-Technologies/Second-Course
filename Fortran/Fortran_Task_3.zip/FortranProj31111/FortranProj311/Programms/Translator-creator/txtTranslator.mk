project : C:\Users\ysm47\Desktop\projects\Programms\Translator-creator\txtTr&
anslator.exe .SYMBOLIC

!include C:\Users\ysm47\Desktop\projects\Programms\Translator-creator\txtTra&
nslator.mk1
